function verif(){
    nom = lieCookie("style");
    creerStyle(nom);
    
}
