function creerStyle(style){
    // var lien_css = document.createElement("link");
    // lien_css.href = style;
    // lien_css.rel = "stylesheet";
    // lien_css.type = "text/css";
    console.log(style);
    document.getElementById("monStyle").href=style;
    creerCookie("style", style, 15);
}